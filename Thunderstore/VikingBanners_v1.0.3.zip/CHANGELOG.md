| `Version` | `Update Notes`                             |
|-----------|--------------------------------------------|
| 1.0.3     | - Update for Valheim 0.217.46              |
| 1.0.2     | - Update for Valheim 0.217.22              |
| 1.0.1     | - Fix issues with WardIsLove compatibility |
| 1.0.0     | - Initial Release                          |