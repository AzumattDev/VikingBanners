| `Version` | `Update Notes`                             |
|-----------|--------------------------------------------|
| 1.0.1     | - Fix issues with WardIsLove compatibility |
| 1.0.0     | - Initial Release                          |